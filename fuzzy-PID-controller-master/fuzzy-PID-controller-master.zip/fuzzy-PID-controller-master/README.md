# fuzzy-PID-controller
This repository uses C++ to implement a fuzzy PID controller to automatically tune PID parameters Kp,Ki and Kd.
